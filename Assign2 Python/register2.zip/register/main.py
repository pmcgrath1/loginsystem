
import os

import webapp2
import jinja2

from google.appengine.ext import ndb

class UserDetail(ndb.Model):
    my_userid = ndb.StringProperty()
    my_email = ndb.StringProperty()
    my_passwd = ndb.StringProperty() 
    my_passwd2 = ndb.StringProperty() 

JINJA = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__)),
    extensions=['jinja2.ext.autoescape'],
    autoescape=True,
)

class LoginHandler(webapp2.RequestHandler):
    def get(self):
        pass

    def post(self):
        pass

class RegisterHandler(webapp2.RequestHandler):
    def get(self):
        template = JINJA.get_template('reg.html')
        self.response.write(template.render(
            { 'the_title': 'Welcome to the Registration Page' } 
        ))

    def post(self):
        userid = self.request.get('userid')
        email = self.request.get('email') 
        passwd = self.request.get('passwd')
        passwd2 = self.request.get('passwd2')

        person = UserDetail()
        person.my_userid = userid
        person.my_email = email
        person.my_passwd = passwd
        person.my_passwd2 = passwd2
        person.put()

        self.redirect('/login')
        

app = webapp2.WSGIApplication([
    ('/register', RegisterHandler),
    ('/processreg', RegisterHandler),
    ('/', LoginHandler),
    ('/login', LoginHandler),
    ('/processlogin', LoginHandler),
], debug=True)
